<?php
(!defined('_CODE'))? die('Truy cap khong hop le'):false;
?>
