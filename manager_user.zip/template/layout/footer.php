<?php
(!defined('_CODE'))? die('Truy cap khong hop le'):false;
?>

<script src="<?php echo _WEB_HOST_TEMPLE?>/js/bootstrap.min.js"></script>

</body>

<footer >
    <div class="footer d-flex justify-content-center align-items-center mt-3" style="
         background-color: rgb(233, 233, 233);
  height: 100px;
  width: 100%;
  box-shadow: 1px 1px 8px rgb(161, 161, 161);
    " >
    <h5> &#9400 Copyright 2023 by <a href="https://www.linkedin.com/public-profile/settings?trk=d_flagship3_profile_self_view_public_profile">@Tan Hung</a></h5>    
</div>
</footer>
