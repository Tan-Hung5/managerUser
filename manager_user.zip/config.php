<?php
const _MODULE = 'Home';
const _ACTION = 'Dasboard';
const _CODE = true; 

define('_WEB_HOST','http://'.$_SERVER['HTTP_HOST'].'/project/manager_user');
define('_WEB_HOST_TEMPLE',_WEB_HOST.'/template');

define('_WEB_PATH',__DIR__);
define('_WEB_PATH_TEMPLATE',_WEB_PATH.'/template');

const _HOST = 'localhost';
const _DB = 'dbuser';
const _USER = 'root';
const _PASSWORD = '';