<?php
(!defined('_CODE'))? die('<h1>Not Found</h1></br><p>The requested URL was not found on this server.</p>'):false;
?>

<h1>404 error</h1>